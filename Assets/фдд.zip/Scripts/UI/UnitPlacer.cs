using UnityEngine;
using UnityEngine.Tilemaps;

public class UnitPlacer : MonoBehaviour
{
    [Header("References")]
    public Camera gameCamera;
    public Tilemap groundTilemap;
    public MapGenerator mapGenerator;  // used for coordinate conversion

    [Header("Unit Placing")]
    public GameObject selectedUnitPrefab;   // set this from UI
    public float unitHeightOffset = 0.1f;

    // Stores units so we don't place more than one on the same tile
    private readonly System.Collections.Generic.Dictionary<Vector2Int, GameObject> placedUnits
        = new System.Collections.Generic.Dictionary<Vector2Int, GameObject>();

    void Update()
    {
        // Left mouse click
        if (Input.GetMouseButtonDown(0))
        {
            TryPlaceUnitAtMouse();
        }
    }

    public void SetUnitPrefab(GameObject prefab)
    {
        selectedUnitPrefab = prefab;
    }

    void TryPlaceUnitAtMouse()
    {
        if (selectedUnitPrefab == null)
        {
            // 🔵 ADDED — no active unit selected
            return;
        }

        Vector3 mouseWorld = gameCamera.ScreenToWorldPoint(Input.mousePosition);
        mouseWorld.z = 0;

        // Convert Unity world position → tile grid coordinate
        Vector3Int cell = groundTilemap.WorldToCell(mouseWorld);

        // Convert grid coordinate to custom offset grid position
        Vector2Int gridPos = new Vector2Int(cell.x + mapGenerator.mapSize / 2,
                                            cell.y + mapGenerator.mapSize / 2);

        // Prevent out of bounds placement
        if (!IsInsideMap(cell))
            return;

        // Prevent placing two units on the same tile
        if (placedUnits.ContainsKey(gridPos))
            return;

        // Convert tile cell position → center of the tile
        Vector3 spawnPos = groundTilemap.GetCellCenterWorld(cell);
        spawnPos.z = -1f; // make sure it renders above tiles
        spawnPos.y += unitHeightOffset;

        // Spawn
        GameObject newUnit = Instantiate(selectedUnitPrefab, spawnPos, Quaternion.identity);
        placedUnits[gridPos] = newUnit;

        // ===============================
        // AUTO-SCALE UNIT TO TILE SIZE
        // ===============================
        SpriteRenderer sr = newUnit.GetComponentInChildren<SpriteRenderer>();
        if (sr != null)
        {
            float tileSize = mapGenerator.tileScale;
            Vector2 spriteSize = sr.sprite.bounds.size;

            float scaleFactor = Mathf.Min(
                tileSize / spriteSize.x,
                tileSize / spriteSize.y
            );

            newUnit.transform.localScale = new Vector3(scaleFactor, scaleFactor, 1f);
        }

        // 🔵 ADDED — disable placing after 1 unit
        selectedUnitPrefab = null;

        Debug.Log($"Unit placed at tile {gridPos.x}, {gridPos.y}");
    }

    bool IsInsideMap(Vector3Int cell)
    {
        int half = mapGenerator.mapSize / 2;
        return cell.x >= -half && cell.x < half &&
               cell.y >= -half && cell.y < half;
    }
}
