using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public class Statistics : MonoBehaviour
{
    public Button backToMenuButton;
    public TMP_Text text;

    private void Start()
    {
        RefreshUI();

        backToMenuButton.onClick.AddListener(() =>
        {
            SceneManager.LoadScene("StartMenuScene");
        });
    }

    private void RefreshUI()
    {
        var s = StatsManager.stats;

        text.text =
            $"Units Created: {s.totalUnitsCreated}\n" +
            $"Units Killed: {s.totalUnitsKilled}\n" +
            $"Gold Earned: {s.totalGoldEarned}\n" +
            $"Gold Spent: {s.totalGoldSpent}\n" +
            $"Total Turns: {s.totalTurnsPlayed}";
    }

    
    public void OnResetStatsButtonPressed()
    {
        StatsManager.Reset();
        RefreshUI();
    }
}