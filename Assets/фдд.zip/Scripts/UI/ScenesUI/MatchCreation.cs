using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MatchCreation : MonoBehaviour
{
    public Toggle smallToggle;
    public Toggle mediumToggle;
    public Toggle largeToggle;

    public void StartMatch()
    {
        int mapSize = 0;

        if (smallToggle.isOn)
        {
            mapSize = 8;
            Debug.LogWarning("shmol");
        }

        else if (mediumToggle.isOn)
        {
            mapSize = 10;
            Debug.LogWarning("mid");
        }
        else if (largeToggle.isOn)
        {
            mapSize = 12;
            Debug.LogWarning("large");
        }
        else
        {
            Debug.LogWarning("No map size selected!");
            return;
        }

        PlayerPrefs.SetInt("MapSize", mapSize);
        SceneManager.LoadScene("MatchScene");
    }

    public void BackToStartMenu()
    {
        SceneManager.LoadScene("StartMenuScene");
    }
}