using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMatch : MonoBehaviour
{
    public GameObject savePanel; // assign in Inspector

    // Called by UI button in match to save game
    public void SaveGame()
    {
        savePanel.SetActive(true);
    }

    public void ExitToMenu()
    {
        SceneManager.LoadScene("StartMenuScene");
    }
}
