using UnityEngine;
using UnityEngine.SceneManagement;


public class StartMenu : MonoBehaviour
{
    public int mapSize = 8;
    
    private void Start() { StatsManager.Load(); }
    // "New Game" button
    public void PlayGame()
    {
        SaveSession.isLoadRequested = false;
        PlayerPrefs.SetInt("MapSize", mapSize);
        SceneManager.LoadScene("MatchScene");
    }

    // "Load Game" button
    public void LoadGame()
    {
        SceneManager.LoadScene("SaveSlotsScene"); // go to slot selection
    }
    public void Stats()
    {
        SceneManager.LoadScene("StatisticsScene"); // go to stats selection
    }


    // Optional "Quit" button
    public void QuitGame()
    {
        Application.Quit();
        Debug.Log("Quit requested.");
    }
}