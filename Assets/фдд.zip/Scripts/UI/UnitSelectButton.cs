using UnityEngine;

public class UnitSelectButton : MonoBehaviour
{
    public UnitPlacer unitPlacer;     // reference to UnitPlacer in scene
    public GameObject unitPrefab;     // prefab this button selects

    public void OnSelectUnit()
    {
        unitPlacer.SetUnitPrefab(unitPrefab);
    }
}