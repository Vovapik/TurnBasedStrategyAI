using UnityEngine;
using UnityEngine.Tilemaps;

public class MapGenerator : MonoBehaviour
{
    [Header("References")]
    public GameController gameController;
    public Tilemap groundTilemap;
    public Sprite groundSprite;
    public Camera gameCamera; // Assign your main camera
    
    [Header("Settings")]
    public int mapSize = 8;
    
    [Header("Tile Settings")]
    public float tileScale = 1f; // Default size
    
    private void Start()
    {
        GenerateTilemap();
        SetupCamera();
    }
    
    [ContextMenu("Generate Tilemap")]
    public void GenerateTilemap()
    {
        mapSize = PlayerPrefs.GetInt("MapSize", 8);
    
        if (groundTilemap == null)
        {
            Debug.LogError("Tilemap reference is missing!");
            return;
        }
    
        if (groundSprite == null)
        {
            Debug.LogError("Ground sprite is missing!");
            return;
        }
    
        groundTilemap.ClearAllTiles();
    
        // Calculate center offset
        int offsetX = -mapSize / 2;
        int offsetY = -mapSize / 2;
    
        TileState[,] tiles = gameController.gameState.tiles;

        for (int x = 0; x < mapSize; x++)
        {
            for (int y = 0; y < mapSize; y++)
            {
                Vector3Int cellPos = new Vector3Int(offsetX + x, offsetY + y, 0);

                // Create a NEW HighlightableTile for every cell
                HighlightableTile tile = ScriptableObject.CreateInstance<HighlightableTile>();
                
                tile.sprite = groundSprite;

                // Apply tile scale
                tile.transform = Matrix4x4.Scale(new Vector3(tileScale, tileScale, 1f));

                groundTilemap.SetTile(cellPos, tile);
            }
        }

    
        Debug.Log($"Successfully generated {mapSize}x{mapSize} tilemap");
        
        // === CAMERA BOUNDARIES ===
        float half = mapSize / 2f;

        CameraController controller = gameCamera.GetComponent<CameraController>();
        if (controller != null)
        {
            controller.SetBounds(
                -half,   // minX
                half,    // maxX
                -half,   // minY
                half     // maxY
            );
        }

    }
    
    void SetupCamera()
    {
        if (gameCamera == null)
        {
            gameCamera = Camera.main;
            if (gameCamera == null)
            {
                Debug.LogError("No camera found! Please assign a camera.");
                return;
            }
        }
        
        // Rotate camera to 45 degrees for diamond view
        gameCamera.transform.rotation = Quaternion.Euler(0, 0, 45);
        
        // Optional: Adjust camera position to better center the rotated view
        CenterCamera();
    }
    
    void CenterCamera()
    {
        if (gameCamera == null) return;
        
        // Calculate center position for the rotated view
        float diagonalSize = mapSize * 1.414f; // mapSize * √2
        float cameraZ = -diagonalSize * 0.7f; // Adjust this value as needed
        
        gameCamera.transform.position = new Vector3(0, 0, cameraZ);
        
        // Adjust orthographic size to fit the entire rotated grid
        if (gameCamera.orthographic)
        {
            gameCamera.orthographicSize = diagonalSize * 0.6f;
        }
    }
    
    [ContextMenu("Clear Tilemap")]
    public void ClearTilemap()
    {
        if (groundTilemap != null)
        {
            groundTilemap.ClearAllTiles();
            Debug.Log("Tilemap cleared");
        }
    }
    
    // Optional: Regenerate with current settings
    [ContextMenu("Regenerate Tilemap")]
    public void RegenerateTilemap()
    {
        GenerateTilemap();
        SetupCamera();
    }
    
    // Helper methods for coordinate conversion
    public Vector2Int WorldToGridPosition(Vector3 worldPosition)
    {
        Vector3Int cell = groundTilemap.WorldToCell(worldPosition);

        int logicX = cell.x + mapSize / 2;
        int logicY = cell.y + mapSize / 2;

        return new Vector2Int(logicX, logicY);
    }
    
    public Vector3 GridToWorldPosition(Vector2Int gridPos)
    {
        int offsetX = -mapSize / 2;
        int offsetY = -mapSize / 2;

        Vector3Int cell = new Vector3Int(
            offsetX + gridPos.x,
            offsetY + gridPos.y,
            0
        );

        return groundTilemap.GetCellCenterWorld(cell);
    }


    public float GetTileWorldSize()
    {
        return tileScale;
    }
    
    public Vector3Int GridToCell(Vector2Int g)
    {
        int offsetX = -mapSize / 2;
        int offsetY = -mapSize / 2;

        return new Vector3Int(offsetX + g.x, offsetY + g.y, 0);
    }

    
}