using UnityEngine;
using TMPro;

public class GoldUI : MonoBehaviour
{
    public GameController gameController;
    public PlayerId playerToShow = PlayerId.Human;

    public TMP_Text goldText;

    private void Update()
    {
        int gold = gameController.GetPlayerGold(playerToShow);
        goldText.text = "Gold: " + gold;
    }
    
    public void Refresh()
    {
        if (gameController == null)
            gameController = FindObjectOfType<GameController>();

        if (gameController != null)
        {
            int gold = gameController.GetPlayerGold(PlayerId.Human);
            goldText.text = "Gold: " + gold;
        }
    }
}