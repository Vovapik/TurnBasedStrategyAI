using System;

[System.Serializable]
public class PlayerState
{
    public PlayerId id;
    public int gold;
}