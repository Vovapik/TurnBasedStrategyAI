using System;

[System.Serializable]
public class TileState
{
    public int x;
    public int y;

    public TileTerrain terrain = TileTerrain.Plain;

    public int unitId = -1;      // index in GameState.units
    public int buildingId = -1;  // index in GameState.buildings
}