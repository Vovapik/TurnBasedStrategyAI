using System.Collections.Generic;

public static class GameCloner
{
    public static GameState Clone(GameState src)
    {
        if (src == null) return null;

        GameState dst = new GameState();

        dst.mapSize      = src.mapSize;
        dst.config       = src.config;   // config is treated as read-only, so we can share
        dst.currentPlayer = src.currentPlayer;
        dst.gameOver     = src.gameOver;
        dst.winner       = src.winner;

        // Players
        dst.players = new List<PlayerState>(src.players.Count);
        foreach (var p in src.players)
        {
            dst.players.Add(new PlayerState
            {
                id   = p.id,
                gold = p.gold
            });
        }

        // Buildings
        dst.buildings = new List<BuildingState>(src.buildings.Count);
        foreach (var b in src.buildings)
        {
            dst.buildings.Add(new BuildingState
            {
                id     = b.id,
                owner  = b.owner,
                type   = b.type,
                x      = b.x,
                y      = b.y,
                hp     = b.hp,
                maxHp  = b.maxHp
            });
        }

        // Units
        dst.units = new List<UnitState>(src.units.Count);
        foreach (var u in src.units)
        {
            dst.units.Add(new UnitState
            {
                id                    = u.id,
                owner                 = u.owner,
                type                  = u.type,
                x                     = u.x,
                y                     = u.y,
                hp                    = u.hp,
                maxHp                 = u.maxHp,
                moveRange             = u.moveRange,
                hasActedThisTurn      = u.hasActedThisTurn,
                actionsLeft           = u.actionsLeft,
                moveCooldownRemaining = u.moveCooldownRemaining,
                isDead                = u.isDead
            });
        }

        // Tiles
        int n = src.mapSize;
        dst.tiles = new TileState[n, n];

        for (int x = 0; x < n; x++)
        {
            for (int y = 0; y < n; y++)
            {
                TileState t = src.tiles[x, y];
                dst.tiles[x, y] = new TileState
                {
                    x          = t.x,
                    y          = t.y,
                    terrain    = t.terrain,
                    unitId     = t.unitId,
                    buildingId = t.buildingId
                };
            }
        }

        return dst;
    }
}
