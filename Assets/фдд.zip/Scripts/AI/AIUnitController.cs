using System;
using System.Collections.Generic;
using UnityEngine;

public class AIUnitController
{
    public void ControlUnits(AIBlackboard bb)
    {
        Debug.Log($"=== AI UNIT PHASE START ===");

        foreach (var u in bb.MyUnits)
        {
            Debug.Log($"AI Unit {u.type} id={u.id} at {u.x},{u.y} | HP={u.hp} | actionsLeft={u.actionsLeft} | cooldown={u.moveCooldownRemaining}");
        }

        var state = bb.State;

        // Snapshot of unit IDs to avoid issues when units die during iteration
        List<int> myUnitIds = new List<int>();
        for (int i = 0; i < state.units.Count; i++)
        {
            UnitState u = state.units[i];
            if (u.isDead) continue;
            if (u.owner == bb.MyId)
                myUnitIds.Add(i);
        }

        // Process in a deterministic order
        myUnitIds.Sort((a, b) =>
        {
            UnitType ta = state.units[a].type;
            UnitType tb = state.units[b].type;
            int ra = GetTypePriority(ta);
            int rb = GetTypePriority(tb);
            return ra.CompareTo(rb);
        });

        foreach (int id in myUnitIds)
        {
            UnitState u = state.units[id];
            if (u.isDead) continue;

            Debug.Log($"--- Processing {u.type} id={u.id} at {u.x},{u.y} ---");

            while (!u.isDead && u.owner == bb.MyId && u.actionsLeft > 0 && !bb.State.gameOver)
            {
                Debug.Log($"Unit {u.type} id={u.id}: actionsLeft={u.actionsLeft}, cooldown={u.moveCooldownRemaining}");

                bool acted = false;

                if (u.type == UnitType.Engineer)
                {
                    acted = ControlEngineer(u, bb);
                }
                else if (u.type == UnitType.Catapult)
                {
                    acted = ControlCatapult(u, bb);
                }
                else if (u.type == UnitType.Archer)
                {
                    acted = ControlArcher(u, bb);
                }
                else
                {
                    acted = ControlMelee(u, bb);
                }

                Debug.Log($"Unit {u.type} id={u.id} acted={acted}");

                if (!acted)
                {
                    Debug.Log($"Unit {u.id} cannot act → stopping unit loop.");
                    break;
                }
            }
        }

        Debug.Log("=== AI UNIT PHASE END ===");
    }

    private int GetTypePriority(UnitType t)
    {
        switch (t)
        {
            case UnitType.Catapult: return 0;
            case UnitType.Archer:   return 1;
            case UnitType.Warrior:
            case UnitType.Chivalry: return 2;
            case UnitType.Engineer: return 3;
            default: return 4;
        }
    }

    // ============================
    //      ATTACK LOGIC
    // ============================

    private bool TryAttackBestTarget(UnitState attacker, AIBlackboard bb)
    {
        var rules = bb.Rules;
        var state = bb.State;

        Debug.Log($"[ATTACK] Scanning attack targets for {attacker.type} id={attacker.id}");

        float bestScore = float.MinValue;
        int bestX = -1;
        int bestY = -1;

        int n = state.mapSize;

        for (int x = 0; x < n; x++)
        {
            for (int y = 0; y < n; y++)
            {
                if (!rules.CanAttack(attacker.id, x, y))
                    continue;

                float score = 0f;
                TileState tile = state.tiles[x, y];

                // ======== ATTACK UNIT ========
                if (tile.unitId != -1)
                {
                    var target = state.units[tile.unitId];

                    // Base unit value
                    int baseValue = AIUtils.GetUnitValue(target.type, bb.Config);
                    score += baseValue;

                    // High priority for catapults
                    if (target.type == UnitType.Catapult)
                    {
                        score += 50f; // always care about hitting catapult
                    }
                    
                    // EXTRA PRIORITY: kill threatening catapult
                    if (bb.EnemyCatapultThreatensCastleOrFort &&
                        target.type == UnitType.Catapult)
                    {
                        score += 200f;  // VERY strong push to kill
                    }

                    // Killing blow bonus
                    int projectedDmg = GetAttackDamage(attacker, target, bb);
                    bool kill = target.hp <= projectedDmg;
                    if (kill)
                    {
                        score += 30f;

                        if (target.type == UnitType.Catapult)
                        {
                            // Extra huge bonus for removing siege
                            score += 80f;
                        }
                    }

                    Debug.Log($"[ATTACK] {attacker.type} can hit unit {target.type} at {x},{y} score={score}");
                }
                // ======== ATTACK BUILDING ========
                else if (tile.buildingId != -1)
                {
                    var b = state.buildings[tile.buildingId];

                    float bVal = AIUtils.GetBuildingValue(b.type, bb.Config);
                    score += bVal * 0.2f;

                    if (b.type == BuildingType.Castle)
                    {
                        score += 40f;

                        // Extra love for catapult bombarding the castle
                        if (attacker.type == UnitType.Catapult)
                            score += 40f;
                    }

                    Debug.Log($"[ATTACK] {attacker.type} can hit BUILDING {b.type} at {x},{y} score={score}");
                }

                if (score > bestScore)
                {
                    bestScore = score;
                    bestX = x;
                    bestY = y;
                }
            }
        }

        if (bestX != -1)
        {
            Debug.Log($"[ATTACK] BEST TARGET chosen at {bestX},{bestY} with score={bestScore}");
            bool ok = rules.Attack(attacker.id, bestX, bestY);
            Debug.Log($"[ATTACK] Attack result = {ok}");
            return ok;
        }

        Debug.Log($"[ATTACK] No valid targets for {attacker.type} id={attacker.id}");
        return false;
    }

    private int GetAttackDamage(UnitState attacker, UnitState target, AIBlackboard bb)
    {
        switch (attacker.type)
        {
            case UnitType.Warrior:   return bb.Config.warriorDamage;
            case UnitType.Archer:    return bb.Config.archerDamage;
            case UnitType.Chivalry:  return bb.Config.chivalryDamage;
            case UnitType.Engineer:  return bb.Config.engineerDamage;
            case UnitType.Catapult:  return bb.Config.catapultDamageVsUnits;
        }
        return 0;
    }

    //       MOVEMENT Helpers

    private bool TryMoveToBetterTile(UnitState u, AIBlackboard bb, Func<int, int, float> scoreFunc)
    {
        var rules = bb.Rules;
        var state = bb.State;

        Debug.Log($"[MOVE] Evaluating move options for {u.type} id={u.id}");

        float bestScore = float.MinValue;
        int bestX = u.x, bestY = u.y;

        float stayScore = scoreFunc(u.x, u.y);
        bestScore = stayScore;

        for (int x = 0; x < state.mapSize; x++)
        {
            for (int y = 0; y < state.mapSize; y++)
            {
                // BASIC MOVEMENT VALIDITY
                if (!rules.CanMoveUnit(u.id, x, y))
                    continue;

                TileState tile = state.tiles[x, y];

                // Forbid stepping onto enemy buildings (blocks attacking them)
                if (tile.buildingId != -1)
                {
                    BuildingState b = state.buildings[tile.buildingId];

                    if (b.owner != u.owner)
                    {
                        Debug.Log($"[MOVE] Forbid stepping on enemy building at {x},{y}");
                        continue;
                    }
                }

                float score = scoreFunc(x, y);
                Debug.Log($"[MOVE] Tile {x},{y} = score {score}");

                if (score > bestScore)
                {
                    bestScore = score;
                    bestX = x;
                    bestY = y;
                }
            }
        }

        Debug.Log($"[MOVE] Best tile = {bestX},{bestY} (score={bestScore}) vs stay={stayScore}");

        if (bestX != u.x || bestY != u.y)
        {
            bool moved = rules.MoveUnit(u.id, bestX, bestY);
            Debug.Log($"[MOVE] Move result = {moved}");
            return moved;
        }

        Debug.Log("[MOVE] Staying in place");
        return false;
    }

    // ============================
    //  UNIT TYPE LOGIC
    // ============================

    private bool ControlMelee(UnitState u, AIBlackboard bb)
    {
        Debug.Log($"[MELEE] {u.id}");

        if (TryAttackBestTarget(u, bb))
            return true;

        int tx = bb.EnemyCastle.x;
        int ty = bb.EnemyCastle.y;

        bool moved = TryMoveToBetterTile(u, bb, (x, y) =>
            MovementScore(u, x, y, tx, ty, bb)
        );

        return moved;
    }

    private bool ControlArcher(UnitState u, AIBlackboard bb)
    {
        Debug.Log($"[ARCHER] {u.id}");

        if (TryAttackBestTarget(u, bb))
            return true;

        int tx = bb.EnemyCastle.x;
        int ty = bb.EnemyCastle.y;

        bool moved = TryMoveToBetterTile(u, bb, (x, y) =>
            MovementScore(u, x, y, tx, ty, bb)
        );

        return moved;
    }

    private bool ControlCatapult(UnitState u, AIBlackboard bb)
    {
        Debug.Log($"[CATAPULT] {u.id}");

        if (TryAttackBestTarget(u, bb))
            return true;

        if (u.moveCooldownRemaining > 0)
        {
            Debug.Log("[CATAPULT] move cooldown");
            return false;
        }

        int tx = bb.EnemyCastle.x;
        int ty = bb.EnemyCastle.y;

        bool moved = TryMoveToBetterTile(u, bb, (x, y) =>
            MovementScore(u, x, y, tx, ty, bb)
        );

        return moved;
    }

    private bool ControlEngineer(UnitState u, AIBlackboard bb)
    {
        Debug.Log($"[ENGINEER] {u.id}");

        if (bb.Rules.CanPlaceFortpost(u.id))
        {
            bb.Rules.PlaceFortpost(u.id);
            return true;
        }

        if (bb.GoldTiles.Count == 0)
            return false;

        TileState target = AIUtils.FindClosestTile(u.x, u.y, bb.GoldTiles);

        bool moved = TryMoveToBetterTile(u, bb, (x, y) =>
            MovementScore(u, x, y, target.x, target.y, bb)
        );

        return moved;
    }

    // ============================
    //  UNIFIED MOVEMENT SCORER
    // ============================

    private float MovementScore(UnitState u, int x, int y, int targetX, int targetY, AIBlackboard bb)
    {
        float score = 0f;

        var cfg = bb.Config;

        // --- 1. Move closer to main target (usually enemy castle) ---
        int curDist = AIUtils.Manhattan(u.x, u.y, targetX, targetY);
        int newDist = AIUtils.Manhattan(x, y, targetX, targetY);
        score += (curDist - newDist) * 4f; // strong push forward

        // Track danger
        int baseDanger = bb.DangerMap[x, y];

        // --- 2. Special treatment: enemy catapults ---
        bool adjacentToCatapult = false;
        int catapultThreatPenalty = 0;
        
        // URGENT: catapult threatens structures → MOVE TO KILL IT
        if (bb.EnemyCatapultThreatensCastleOrFort && bb.ThreateningCatapult != null)
        {
            int distNow = AIUtils.Manhattan(u.x, u.y, bb.ThreateningCatapult.x, bb.ThreateningCatapult.y);
            int distNew = AIUtils.Manhattan(x, y, bb.ThreateningCatapult.x, bb.ThreateningCatapult.y);

            // Units should aggressively close in on catapult
            score += (distNow - distNew) * 30f;   // Massive weight

            // Melee units love being adjacent to kill catapult
            if (distNew == 1 && (u.type == UnitType.Warrior || u.type == UnitType.Chivalry))
                score += 120f;

            // Archers prefer tiles that can shoot catapult
            if (distNew >= 1 && distNew <= bb.Config.archerRange && u.type == UnitType.Archer)
                score += 80f;
        }

        foreach (var e in bb.EnemyUnits)
        {
            if (e.type != UnitType.Catapult)
                continue;

            int d = AIUtils.Manhattan(x, y, e.x, e.y);

            if (d == 1)
                adjacentToCatapult = true;

            if (d >= 1 && d <= cfg.catapultRange)
            {
                int localPenalty = 0;
                switch (u.type)
                {
                    case UnitType.Archer:
                        localPenalty = 30; // archers really don’t want to chill in cata range
                        break;
                    case UnitType.Engineer:
                        localPenalty = 40; // protect the economy
                        break;
                    case UnitType.Warrior:
                    case UnitType.Chivalry:
                        localPenalty = 15; // melee can take some risk
                        break;
                    default:
                        localPenalty = 20;
                        break;
                }
                catapultThreatPenalty += localPenalty;
            }

            // Archers: prefer tiles where they can shoot catapult
            if (u.type == UnitType.Archer && d >= 1 && d <= cfg.archerRange)
            {
                score += 35f; // good sniping position
            }
        }

        // --- 3. Ranged units want enemies in shooting range generally ---
        if (u.type == UnitType.Archer)
        {
            foreach (var e in bb.EnemyUnits)
            {
                int d = AIUtils.Manhattan(x, y, e.x, e.y);
                if (d >= 1 && d <= cfg.archerRange)
                    score += 10f; // good firing tile

                if (d <= 1)
                    score -= 10f; // avoid standing in melee range
            }
        }

        // --- 4. Catapult optimal distance to CASTLE ---
        if (u.type == UnitType.Catapult && bb.EnemyCastle != null)
        {
            int dCastle = AIUtils.Manhattan(x, y, bb.EnemyCastle.x, bb.EnemyCastle.y);
            if (dCastle >= 1 && dCastle <= cfg.catapultRange)
                score += 40f; // perfect firing distance
        }

        // --- 5. Danger penalties, modified for catapult-hunting logic ---

        // If we’re adjacent to a catapult, we might want to KILL it, so danger is less scary
        if (adjacentToCatapult && (u.type == UnitType.Warrior || u.type == UnitType.Chivalry || u.type == UnitType.Engineer))
        {
            // We are in position to smack the catapult next action
            score += 40f;           // strong incentive to move next to catapult
            score -= baseDanger * 0.2f;
            score -= catapultThreatPenalty * 0.2f;
        }
        else
        {
            // Normal behavior: avoid danger
            score -= baseDanger * 2f;
            score -= catapultThreatPenalty * 1.0f;
        }

        return score;
    }
}
