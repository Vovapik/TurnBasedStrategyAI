using System;
using UnityEngine;

public class AIManager
{
    private readonly GameState _state;
    private readonly GameRules _rules;

    private readonly AIBlackboard _bb = new AIBlackboard();
    private readonly AIPerception _perception = new AIPerception();
    private readonly AIGoalSelector _goalSelector = new AIGoalSelector();
    private readonly AIEconomy _economy = new AIEconomy();
    private readonly AIUnitController _unitController = new AIUnitController();

    public AIManager(GameState state, GameRules rules)
    {
        _state = state;
        _rules = rules;

        _bb.State = state;
        _bb.Rules = rules;
    }

    /// <summary>
    /// Perform entire AI turn: perceive, decide, act, then end turn.
    /// Assumes GameRules.StartTurn() was already called and currentPlayer == AI. :contentReference[oaicite:7]{index=7}
    /// </summary>
    public void TakeTurn()
    {
        if (_state.gameOver)
            return;

        // 1. Perception
        _perception.BuildBlackboard(_bb);

        // 2. Decide strategic goal
        _bb.GlobalGoal = _goalSelector.DecideGoal(_bb);

        // 3. Economy: fortposts + unit production
        _economy.RunEconomy(_bb);

        // 4. Control units (movement + attacks)
        _unitController.ControlUnits(_bb);

        // 5. End AI turn -> will switch back to human and call StartTurn for them
        _rules.EndTurn();
    }
}