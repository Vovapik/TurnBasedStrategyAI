public static class SaveSession
{
    public static bool isLoadRequested = false;
    public static int loadSlot = 1;
}